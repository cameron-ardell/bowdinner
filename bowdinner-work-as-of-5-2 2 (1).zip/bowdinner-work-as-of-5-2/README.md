# bowdinner
Final project for Mobile Computing Spring 2016


sorry for the title of this branch, was result of github being picky
anyway, things are going along nicely. I think I can get the invite specific person feature to be same view as random thing actually
