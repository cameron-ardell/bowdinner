//
//  MealUpdateViewController.swift
//  testingTables
//
//  Created by Sophia M. Ardell on 5/1/16.
//  Copyright © 2016 Sophia M. Ardell. All rights reserved.
//

import UIKit

@IBDesignable class MealUpdateViewController: UIViewController, UIPickerViewDataSource, UIPickerViewDelegate  {
    
    

    override func viewDidLoad() {
        super.viewDidLoad()

        //setting up delegate and datasource for first meal
        locationOnePicker.delegate = self
        locationOnePicker.dataSource = self
        
        
        //setting up time formatting
        timeFormatter.dateFormat = "h:mm a"
        timeFormatter.dateStyle = NSDateFormatterStyle.NoStyle
        timeFormatter.timeStyle = NSDateFormatterStyle.ShortStyle
        timeFormatter.AMSymbol = "AM"
        timeFormatter.PMSymbol = "PM"
        currentTime = timeFormatter.stringFromDate( NSDate() )

        //makes sure back button fits on screen
        backToNewsfeed.titleLabel?.adjustsFontSizeToFitWidth = true
        mealOneTitle.adjustsFontSizeToFitWidth = true
        
        
        

    }

    override func didReceiveMemoryWarning() {
        super.didReceiveMemoryWarning()
        // Dispose of any resources that can be recreated.
    }
    
    
    //all options for dining location for picker wheel
    let diningData = ["Moulton", "Thorne", "Pub", "either dining hall"]
    
    //plan for each meal you could possibly set
    var plan1: [String] = ["12:00 AM", "12:00 AM", "unavailable", "unavailable"]
    var plan2: [String] = ["12:00 AM", "12:00 AM", "unavailable", "unavailable"]
    var plan3: [String] = ["unavailable", "unavailable", "unavailable", "unavailable"]
    
    //to modify times outputted by time picker wheel
    let timeFormatter = NSDateFormatter()
    var currentTime: String = "fuck this"
    
    
    @IBOutlet weak var backToNewsfeed: UIButton!
    @IBOutlet weak var mealOneTitle: UILabel!
    

    //
    //setting picker wheel information for first wheel
    //
    @IBOutlet weak var locationOnePicker: UIPickerView!
    @IBOutlet weak var beginOneLabel: UIDatePicker!
    @IBOutlet weak var endOneLabel: UIDatePicker!
    @IBAction func beginOne(sender: AnyObject) {
        //only update if end time is later
        if (beginOneLabel.date.compare(endOneLabel.date)) != NSComparisonResult.OrderedDescending {
            plan1[0] = timeFormatter.stringFromDate(beginOneLabel.date)
            plan1[1] = timeFormatter.stringFromDate(endOneLabel.date)
        }
    }
    @IBAction func endOne(sender: AnyObject) {
        //only update if end time is later
        if (beginOneLabel.date.compare(endOneLabel.date)) != NSComparisonResult.OrderedDescending {
            plan1[0] = timeFormatter.stringFromDate(beginOneLabel.date)
            plan1[1] = timeFormatter.stringFromDate(endOneLabel.date)
        }
    }
    
    
    
    
    
        
        
        
        
        
        
        
    // MARK: - Delegates and data sources for dining location picker wheel
    
    //data sources
    func numberOfComponentsInPickerView(pickerView: UIPickerView) -> Int {
        return 1
    }
    
    func pickerView(pickerView: UIPickerView, numberOfRowsInComponent component: Int) -> Int {
        return diningData.count
    }
    
    //delegates
    func pickerView(pickerView: UIPickerView, titleForRow row: Int, forComponent component: Int) -> String? {
        return diningData[row]
    }
    
    func pickerView(pickerView: UIPickerView, didSelectRow row: Int, inComponent component: Int) {
        switch(pickerView.tag) {
            case 1:
                plan1[2] = diningData[row]
            case 2:
                plan2[2] = diningData[row]
            case 3:
                plan3[2] = diningData[row]
            default:
                break
        }
    }

}
