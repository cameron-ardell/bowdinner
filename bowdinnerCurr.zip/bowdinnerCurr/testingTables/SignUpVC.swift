//
//  SignUpVC.swift
//  testingTables
//
//  Created by Marcus E. Christiansen on 5/7/16.
//  Copyright © 2016 Sophia M. Ardell. All rights reserved.
//

import UIKit

class SignUpVC: UIViewController {

    @IBOutlet weak var username: UITextField!
    
    @IBOutlet weak var password: UITextField!
    
    @IBOutlet weak var confirmPassword: UITextField!

    @IBOutlet weak var classYear: UITextField!
    
    @IBOutlet weak var Major: UITextField!
    
    @IBAction func userSignUp(sender: UIButton) {
        
        let newUserName = username.text! as NSString
        let newPassword = password.text! as NSString
        let confirmNewPassword = confirmPassword.text! as NSString
        
        if (newUserName == "" || newPassword == "") {
            let alertController = UIAlertController(title: "Sign Up Failed", message: "Username or Password can't be empty", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Retry", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alertController, animated: true, completion: nil)
            
        }
        
        else if (newPassword != confirmNewPassword) {
            let alertController = UIAlertController(title: "Sign Up Failed", message: "Passwords do not match", preferredStyle: UIAlertControllerStyle.Alert)
            alertController.addAction(UIAlertAction(title: "Retry", style: UIAlertActionStyle.Default, handler: nil))
            self.presentViewController(alertController, animated: true, completion: nil)
            
            
        }
        
        else {
            
        }
        
    }
    
    
    @IBAction func signUpToLogIn(sender: UIButton) {
        self.dismissViewControllerAnimated(true, completion: nil)
        
    }
    
}
