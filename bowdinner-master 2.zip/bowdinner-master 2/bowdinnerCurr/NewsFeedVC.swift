//
//  NewsFeed.swift
//  testingTables
//
//  Created by Marcus Esben Fredskov Christiansen on 5/8/16.
//  Copyright © 2016 Sophia M. Ardell. All rights reserved.
//

import UIKit

class NewsFeed: UIViewController {
    
    override func viewDidAppear(animated: Bool) {
        self.performSegueWithIdentifier("goToLogin", sender: self)
    }

}
