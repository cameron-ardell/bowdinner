//
//  DiningHallPicker.swift
//  testingTables
//
//  Created by Sophia M. Ardell on 5/2/16.
//  Copyright © 2016 Sophia M. Ardell. All rights reserved.
//

import UIKit

class DiningHallPicker: UIPickerView {

    /*
    // Only override drawRect: if you perform custom drawing.
    // An empty implementation adversely affects performance during animation.
    override func drawRect(rect: CGRect) {
        // Drawing code
    }
    */
    
    

}
