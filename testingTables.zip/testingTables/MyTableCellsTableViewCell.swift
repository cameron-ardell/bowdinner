//
//  MyTableCellsTableViewCell.swift
//  testingTables
//
//  Created by Sophia M. Ardell on 4/25/16.
//  Copyright © 2016 Sophia M. Ardell. All rights reserved.
//

import UIKit

class MyTableCellsTableViewCell: UITableViewCell {

    override func awakeFromNib() {
        super.awakeFromNib()
        // Initialization code
    }

    override func setSelected(selected: Bool, animated: Bool) {
        super.setSelected(selected, animated: animated)

        // Configure the view for the selected state
    }

}
