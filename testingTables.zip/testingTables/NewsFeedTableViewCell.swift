//
//  NewsFeedTableViewCell.swift
//  testingTables
//
//  Created by Sophia M. Ardell on 5/1/16.
//  Copyright © 2016 Sophia M. Ardell. All rights reserved.
//

import UIKit

class NewsFeedTableViewCell: UITableViewCell {

   
    
    @IBOutlet weak var myLabel: UILabel!
    
    func changeLabel(name: String, startTime: String, endTime: String, location: String) {
        
        myLabel.text = name + " is available from " + startTime + " to " + endTime + "!\nDining location preference: " + location + "."
        
    }
    
    
    /*func prepareForSegue(segue: UIStoryboardSegue, sender: AnyObject) {
        
        if let identifier = segue.identifier {
            switch identifier {
                case "seeProfileSegue":
                    let cell = sender as? NewsFeedTableViewCell
                    if let indexPath = tableView.indexPathForCell(cell) {
                        
                    }
                default: break
            }
        }
    }*/    

}
