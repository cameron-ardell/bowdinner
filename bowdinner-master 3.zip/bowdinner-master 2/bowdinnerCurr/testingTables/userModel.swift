//
//  userModel.swift
//  testingTables
//
//  Created by Marcus Esben Fredskov Christiansen on 5/8/16.
//  Copyright © 2016 Sophia M. Ardell. All rights reserved.
//

import Foundation

class userModel: NSObject {
    
    var ID: Int?
    var name: String?
    var year: Int?
    //var bio: String?
    var status: Bool?
    var time: String?
    var place: String?
    var password: String?
    
    override init() {
        
    }
    
    init(ID:Int, name:String, year:Int, bio:String, status:Bool, time:String, place: String, password: String) {
        self.ID = ID
        self.name = name
        self.year = year
        //self.bio = bio
        self.status = status
        self.time = time
        self.place = place
        self.password = password
        
    }
    
    override var description: String {
        return "ID: \(ID)"
    }
    
    
    
    
    
}
